const levelRoles = [
  "561302712470208513", //new
  "561302846637867008", //friendly
  "561302954112581643", //reg
  "568203856119463936", //talk
  "568204223247024138", //superstar
  "561303174846218398", //devoted
  "568206840551440386", //divine
  "568204471855743002" //ambass
];

module.exports = levelRoles;
