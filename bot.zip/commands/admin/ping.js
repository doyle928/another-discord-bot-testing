exports.run = (client, message) => {
  message.channel.send("pong");
};
